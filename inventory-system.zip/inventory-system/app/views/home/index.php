<?php layout('app'); ?>

<?php section('title'); ?>
    Home
<?php endsection(); ?>

<?php section('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                Home
            </div>
        </div>
    </div>
</div>
<?php endsection(); ?>

