<?php

namespace app\models;

use core\Model;

class ReturnedItem extends Model
{
    protected $table = 'returned_items';
}
