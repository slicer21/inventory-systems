<?php

namespace app\models;

use core\Model;

class RenewedItem extends Model
{
    protected $table = 'renewed_items';
}
