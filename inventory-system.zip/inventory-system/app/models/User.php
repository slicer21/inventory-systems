<?php

namespace app\models;

use core\Model;

class User extends Model
{
    protected $table = 'users'; // The table associated with the User model
}
