<?php

namespace app\models;

use core\Model;

class Category extends Model
{
    protected $table = 'categories'; // The table associated with the User model
}
