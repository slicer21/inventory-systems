<?php

namespace app\models;

use core\Model;

class BorrowedItem extends Model
{
    protected $table = 'borrowed_items';
}
