<?php

namespace app\models;

use core\Model;

class Attendance extends Model
{
    protected $table = 'attendance';
}
