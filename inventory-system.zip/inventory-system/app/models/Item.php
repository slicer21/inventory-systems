<?php

namespace app\models;

use core\Model;

class Item extends Model
{
    protected $table = 'items'; // The table associated with the User model
}
